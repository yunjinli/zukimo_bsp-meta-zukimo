"""Python Interface for the infineon BGT60LTR11 doppler radar sensor.

The Python package allows an easy and pythonic way to access the BGT60LTR11 
doppler radar sensor.
"""